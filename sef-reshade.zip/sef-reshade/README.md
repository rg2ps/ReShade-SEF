\# ReShade Real-Time Simulated Exposure Fusion


Simulated exposure fusion technique, adapted to real time usage compatible with ReShade software.
This tech allows to local exposure control depending on the content of the image.


Installation: Download the archive and extract the "Shaders" folder into your main "reshade-shaders" folder

